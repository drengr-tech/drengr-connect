import { connect, getVerificationMessage } from "./identity";

export {
    connect,
    getVerificationMessage
}